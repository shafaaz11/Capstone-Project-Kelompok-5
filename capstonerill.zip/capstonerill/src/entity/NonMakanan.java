/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import database.Database;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class NonMakanan extends Barang{
    String beratBarang,ukuranBarang;
    static ArrayList<NonMakanan> arrayNonMakanan = new ArrayList<>();
    static Database db = new Database();

    public NonMakanan(String beratBarang, String ukuranBarang, String idBarang, String namaBarang, String HargaBarang) throws SQLException {
        super(idBarang, namaBarang, HargaBarang);
        this.beratBarang = beratBarang;
        this.ukuranBarang = ukuranBarang;
    }

    public String getBeratBarang() {
        return beratBarang;
    }

    public void setBeratBarang(String beratBarang) {
        this.beratBarang = beratBarang;
    }

    public String getUkuranBarang() {
        return ukuranBarang;
    }

    public void setUkuranBarang(String ukuranBarang) {
        this.ukuranBarang = ukuranBarang;
    }

    public String getIdBarang() {
        return idBarang;
    }

    public void setIdBarang(String idBarang) {
        this.idBarang = idBarang;
    }

    public String getNamaBarang() {
        return namaBarang;
    }

    public void setNamaBarang(String namaBarang) {
        this.namaBarang = namaBarang;
    }

    public String getHargaBarang() {
        return HargaBarang;
    }

    public void setHargaBarang(String HargaBarang) {
        this.HargaBarang = HargaBarang;
    }
    
    
    
    public static ArrayList<NonMakanan> readNonMakanan() throws SQLException{
        arrayNonMakanan.clear();
        String query = "SELECT barang.*, non_makanan.berat_barang, non_makanan.ukuran_barang FROM barang INNER JOIN non_makanan ON barang.id_barang = non_makanan.id_barang;";
        ResultSet rs = db.executeSelectQuery(query);
        while (rs.next()) {            
            String id = rs.getString("id_barang");
            String nama = rs.getString("nama_barang");
            String harga = rs.getString("harga_barang");
            String berat = rs.getString("berat_barang");
            String ukuran = rs.getString("ukuran_barang");
            NonMakanan barangBaru = new NonMakanan(berat, ukuran, id, nama, harga);
            arrayNonMakanan.add(barangBaru);
        }
        return arrayNonMakanan;
    }
    
    public static void createNonMakanan(String idBarang, String namaBarang, String hargaBarang,String berat,String ukuran) throws SQLException{
        NonMakanan makananBaru = new NonMakanan(berat, ukuran, idBarang, namaBarang, hargaBarang);
        arrayNonMakanan.add(makananBaru);
        String query = String.format("INSERT INTO non_makanan VALUES ('%s','%s','%s')",
                makananBaru.getIdBarang(),makananBaru.getBeratBarang(),makananBaru.getUkuranBarang());
        db.executeUpdateQuery(query);
    }
    
    public static void deleteNonMakanan(String idBarang) throws SQLException{
        for (NonMakanan nonMakanan : arrayNonMakanan) {
            if (nonMakanan.getIdBarang().equals(idBarang)) {
                arrayNonMakanan.remove(nonMakanan);
                String query = String.format("DELETE FROM non_makanan WHERE Id_Barang = '%s'", nonMakanan.getIdBarang());
                db.executeUpdateQuery(query);
                break;
            }
        }
    }
    
    public static void updateNonMakanan(String idBarang,String berat,String ukuran) throws SQLException{
        for (NonMakanan nonMakanan : arrayNonMakanan) {
            if (nonMakanan.getIdBarang().equals(idBarang)) {
                nonMakanan.setBeratBarang(berat);
                nonMakanan.setUkuranBarang(ukuran);
                String query = String.format("UPDATE non_makanan SET Berat_Barang = '%s', Ukuran_Barang = '%s' WHERE Id_Barang = '%s' ",
                        nonMakanan.getBeratBarang(),nonMakanan.getUkuranBarang(),nonMakanan.getIdBarang());
                db.executeUpdateQuery(query);
            }
        }
    }
}
