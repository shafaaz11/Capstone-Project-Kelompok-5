/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import database.Database;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class Makanan extends Barang{
    
    String tanggalKdl, asalProduk;
    static ArrayList<Makanan> arrayMakanan = new ArrayList<>();
    static Database db = new Database();

    public Makanan(String tanggalKdl, String asalProduk, String namaBarang, String hargaBarang, String idBarang) throws SQLException {
        super(idBarang, namaBarang, hargaBarang);
        this.tanggalKdl = tanggalKdl;
        this.asalProduk = asalProduk;
    }

    public String getTanggalKdl() {
        return tanggalKdl;
    }

    public void setTanggalKdl(String tanggalKdl) {
        this.tanggalKdl = tanggalKdl;
    }

    public String getAsalProduk() {
        return asalProduk;
    }

    public void setAsalProduk(String asalProduk) {
        this.asalProduk = asalProduk;
    }

    public String getIdBarang() {
        return idBarang;
    }

    public void setIdBarang(String idBarang) {
        this.idBarang = idBarang;
    }

    public String getNamaBarang() {
        return namaBarang;
    }

    public void setNamaBarang(String namaBarang) {
        this.namaBarang = namaBarang;
    }

    public String getHargaBarang() {
        return HargaBarang;
    }

    public void setHargaBarang(String HargaBarang) {
        this.HargaBarang = HargaBarang;
    }

    public static ArrayList<Makanan> readMakanan() throws SQLException{
        arrayMakanan.clear();
        String query = "SELECT barang.*, makanan.tgl_kadaluarsa, makanan.asal_produk FROM barang INNER JOIN makanan ON barang.id_barang = makanan.id_barang;";
        ResultSet rs = db.executeSelectQuery(query);
        while (rs.next()) {            
            String id = rs.getString("id_Barang");
            String nama = rs.getString("nama_barang");
            String harga = rs.getString("harga_barang");
            String tanggal = rs.getString("tgl_kadaluarsa");
            String asal = rs.getString("asal_produk");
            Makanan barangBaru = new Makanan(tanggal,asal,nama,harga,id);
            arrayMakanan.add(barangBaru);
        }
        return arrayMakanan;
    }
    
    public static void createMakanan(String idBarang, String namaBarang, String hargaBarang,String tanggal,String asal) throws SQLException{
        Makanan makananBaru = new Makanan(tanggal, asal, namaBarang,hargaBarang,idBarang);
        arrayMakanan.add(makananBaru);
        String query = String.format("INSERT INTO makanan VALUES ('%s','%s','%s')",
                makananBaru.getIdBarang(),makananBaru.getTanggalKdl(),makananBaru.getAsalProduk());
        db.executeUpdateQuery(query);
    }
    
    public static void deleteMakanan(String idBarang) throws SQLException{
        for (Makanan makanan : arrayMakanan) {
            if (makanan.getIdBarang().equals(idBarang)) {
                arrayMakanan.remove(makanan);
                String query = String.format("DELETE FROM makanan WHERE Id_Barang = '%s'", makanan.getIdBarang());
                db.executeUpdateQuery(query);
                break;
            }
        }
    }
    
    public static void updateMakanan(String idBarang,String tanggal,String asal) throws SQLException{
        for (Makanan makanan : arrayMakanan) {
            if (makanan.getIdBarang().equals(idBarang)) {
                makanan.setTanggalKdl(tanggal);
                makanan.setAsalProduk(asal);
                String query = String.format("UPDATE makanan SET Tgl_Kadaluarsa = '%s', Asal_Produk = '%s' WHERE Id_Barang = '%s' ",
                        makanan.getTanggalKdl(),makanan.getAsalProduk(),makanan.getIdBarang());
                db.executeUpdateQuery(query);
            }
        }
    }      
}
