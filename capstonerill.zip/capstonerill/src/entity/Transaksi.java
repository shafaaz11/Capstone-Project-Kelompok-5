/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.sql.SQLException;

/**
 *
 * @author ASUS
 */
public class Transaksi {
    
    String idTransaksi, idKaryawan, idPelanggan,idBarang,tanggal;
    static database.Database db = new database.Database();
    
    public Transaksi(String idTransaksi, String idKaryawan, String idPelanggan, String idBarang,String tanggal) {
        this.idTransaksi = idTransaksi;
        this.idKaryawan = idKaryawan;
        this.idPelanggan = idPelanggan;
        this.idBarang = idBarang;
        this.tanggal = tanggal;
    }

    public String getTanggal() {
        return tanggal;
    }

    public String getIdTransaksi() {
        return idTransaksi;
    }

    public String getIdKaryawan() {
        return idKaryawan;
    }

    public String getIdPelanggan() {
        return idPelanggan;
    }

    public String getIdBarang() {
        return idBarang;
    }

    public static void insertTransaksi(String idTransaksi,String idKaryawan,String idPelanggan,String idBarang,String tanggal) throws SQLException{
         Transaksi newTransaksi = new Transaksi(idTransaksi, idKaryawan, idPelanggan, idBarang,tanggal);
         String qq = String.format("INSERT INTO transaksi VALUES ('%s','%s','%s','%s','%s')",
                 newTransaksi.getIdTransaksi(),newTransaksi.getIdKaryawan(),newTransaksi.getIdPelanggan(),newTransaksi.getIdBarang(),newTransaksi.getTanggal());
         db.executeUpdateQuery(qq);
    }
}
