/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.sql.SQLException;
import java.util.ArrayList;


public class Pelanggan {
    
    String idPelanggan, nama_pelanggan;
    static database.Database db = new database.Database();

    public Pelanggan(String idPelanggan, String nama_pelanggan) {
        this.idPelanggan = idPelanggan;
        this.nama_pelanggan = nama_pelanggan;
    }

    public String getIdPelanggan() {
        return idPelanggan;
    }

    public void setIdPelanggan(String idPelanggan) {
        this.idPelanggan = idPelanggan;
    }

    public String getNama_pelanggan() {
        return nama_pelanggan;
    }

    public void setNama_pelanggan(String nama_pelanggan) {
        this.nama_pelanggan = nama_pelanggan;
    }
    
    public static void createPelanggan(String id, String nama) throws SQLException{
        Pelanggan newPelanggan = new Pelanggan(id, nama);
        String qq = String.format("INSERT INTO pelanggan VALUES ('%s','%s')", newPelanggan.getIdPelanggan(),newPelanggan.getNama_pelanggan());
        db.executeUpdateQuery(qq);        
    }
}
