/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import database.Database;
import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class Barang {
    
    String idBarang,namaBarang,HargaBarang;
    static Database db = new Database();
    static ArrayList<Barang> arrayBarang = new ArrayList<>();

    public Barang(String idBarang, String namaBarang, String HargaBarang) throws SQLException {
        this.idBarang = idBarang;
        this.namaBarang = namaBarang;
        this.HargaBarang = HargaBarang;
    }

    public String getIdBarang() {
        return idBarang;
    }

    public void setIdBarang(String idBarang) {
        this.idBarang = idBarang;
    }

    public String getNamaBarang() {
        return namaBarang;
    }

    public void setNamaBarang(String namaBarang) {
        this.namaBarang = namaBarang;
    }

    public String getHargaBarang() {
        return HargaBarang;
    }

    public void setHargaBarang(String HargaBarang) {
        this.HargaBarang = HargaBarang;
    }
    
    public static ArrayList<Barang> readBarang() throws SQLException{
        arrayBarang.clear();
        String query = "SELECT * FROM barang";
        ResultSet rs = db.executeSelectQuery(query);
        while (rs.next()) {            
            String id = rs.getString("id_barang");
            String nama = rs.getString("nama_barang");
            String harga = rs.getString("harga_barang");
            Barang barangBaru = new Barang(id, nama, harga);
            arrayBarang.add(barangBaru);
        }return arrayBarang;
    }
    
    public static void createBarang(String idBarang, String namaBarang, String hargaBarang) throws SQLException{
        Barang barangBaru = new Barang(idBarang, namaBarang, hargaBarang);
        arrayBarang.add(barangBaru);
        String query = String.format("INSERT INTO barang VALUES ('%s','%s','%s')",
                barangBaru.getIdBarang(),barangBaru.getNamaBarang(),barangBaru.getHargaBarang());
        db.executeUpdateQuery(query);
    }
    
    public static void deleteBarang(String idBarang) throws SQLException{
        for (Barang barang : arrayBarang) {
            if (barang.getIdBarang().equals(idBarang)) {
                arrayBarang.remove(barang);
                String query = String.format("DELETE FROM barang WHERE id_barang = '%s'", barang.getIdBarang());
                db.executeUpdateQuery(query);
                break;
            }
        }
    }
    
    public static void updateBarang(String idBarang, String namaBarang, String hargaBarang) throws SQLException{
        for (Barang barang : arrayBarang) {
            if (barang.getIdBarang().equals(idBarang)) {
                barang.setHargaBarang(hargaBarang);
                barang.setNamaBarang(namaBarang);
                String query = String.format("UPDATE barang SET nama_barang = '%s', harga_barang = '%s' WHERE id_barang = '%s' ",
                        barang.getNamaBarang(),barang.getHargaBarang(),barang.getIdBarang());
                db.executeUpdateQuery(query);
            }
        }
    }
}
