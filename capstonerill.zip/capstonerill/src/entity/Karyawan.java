/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import static entity.Makanan.arrayMakanan;
import static entity.Makanan.db;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class Karyawan {
    String idKaryawan,namaKaryawan;
    static ArrayList<Karyawan> arrayKaryawan = new ArrayList<>();

    public Karyawan(String idKaryawan, String namaKaryawan) {
        this.idKaryawan = idKaryawan;
        this.namaKaryawan = namaKaryawan;
    }

    public String getIdKaryawan() {
        return idKaryawan;
    }

    public String getNamaKaryawan() {
        return namaKaryawan;
    }
    public static void insertKaryawan(String id,String nama) throws SQLException{
        Karyawan karyawanBaru = new Karyawan(id,nama);
        arrayKaryawan.add(karyawanBaru);
        String query = String.format("INSERT INTO karyawan VALUES ('%s','%s')",
                karyawanBaru.getIdKaryawan(),karyawanBaru.getNamaKaryawan());
        db.executeUpdateQuery(query);
    }
    public static ArrayList<Karyawan> readKaryawan() throws SQLException{
        arrayKaryawan.clear();
        String query = "SELECT * FROM karyawan";
        ResultSet rs = db.executeSelectQuery(query);
        while (rs.next()) {            
            String id = rs.getString("id_karyawan");
            String nama = rs.getString("nama_karyawan");
            Karyawan karyawanBaru = new Karyawan(id,nama);
            arrayKaryawan.add(karyawanBaru);
        }return arrayKaryawan;
    }
}
