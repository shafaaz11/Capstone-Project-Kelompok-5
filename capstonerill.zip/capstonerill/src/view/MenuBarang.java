/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

import java.sql.ResultSet;
import entity.Makanan;
import entity.NonMakanan;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import entity.Barang;

/**
 *
 * @author Asus Vivobook
 */
public class MenuBarang extends javax.swing.JFrame {

    database.Database db = new database.Database();
    
    public MenuBarang() throws SQLException {
        initComponents();
        tableMakanan.getTableHeader().setReorderingAllowed(false);
        tableNon.getTableHeader().setReorderingAllowed(false);
        Barang.readBarang();
        Makanan.readMakanan();
        NonMakanan.readNonMakanan(); 
    }
    
    private void changePanel(JPanel panel, JPanel newPanel){
        panel.removeAll();
        panel.repaint();
        panel.revalidate();
        
        panel.add(newPanel);
        panel.repaint();
        panel.revalidate();
    } 
    
    private void clearField(){
        txtHarga.setText("");
        txtId.setText("");
        txtNama.setText("");
    }
    
        
    private void kembalibtnActionPerformed(java.awt.event.ActionEvent evt) throws SQLException {                                     
        KaryawanMenu km = new KaryawanMenu();
        km.setVisible(true);
        this.dispose();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jTextField1 = new javax.swing.JTextField();
        readbtn = new javax.swing.JButton();
        updatebtn = new javax.swing.JButton();
        deletebtn = new javax.swing.JButton();
        createbtn = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        txtId = new javax.swing.JTextField();
        txtNama = new javax.swing.JTextField();
        txtHarga = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        radioMakanan = new javax.swing.JRadioButton();
        radioNon = new javax.swing.JRadioButton();
        jPanel2 = new javax.swing.JPanel();
        paneltabelMakanan = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableMakanan = new javax.swing.JTable();
        paneltabelNon = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tableNon = new javax.swing.JTable();
        bg = new javax.swing.JLabel();

        jTextField1.setText("jTextField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        readbtn.setText("Read");
        readbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                readbtnActionPerformed(evt);
            }
        });
        getContentPane().add(readbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 310, -1, -1));

        updatebtn.setText("Update");
        updatebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatebtnActionPerformed(evt);
            }
        });
        getContentPane().add(updatebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 310, -1, -1));

        deletebtn.setText("Delete");
        deletebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletebtnActionPerformed(evt);
            }
        });
        getContentPane().add(deletebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 310, -1, -1));

        createbtn.setText("Create");
        createbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createbtnActionPerformed(evt);
            }
        });
        getContentPane().add(createbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 310, -1, -1));

        jButton1.setText("Kembali");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 310, -1, -1));
        getContentPane().add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 140, 210, -1));
        getContentPane().add(txtNama, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 180, 210, -1));
        getContentPane().add(txtHarga, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 220, 210, -1));

        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Nama");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 180, -1, -1));

        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Harga");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 220, -1, -1));

        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Id Barang");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 140, 60, -1));

        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Tipe Barang");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 260, -1, -1));

        buttonGroup1.add(radioMakanan);
        radioMakanan.setForeground(new java.awt.Color(0, 0, 0));
        radioMakanan.setText("Makanan");
        getContentPane().add(radioMakanan, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 260, -1, -1));

        buttonGroup1.add(radioNon);
        radioNon.setForeground(new java.awt.Color(0, 0, 0));
        radioNon.setText("Non Makanan");
        getContentPane().add(radioNon, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 260, -1, -1));

        jPanel2.setLayout(new java.awt.CardLayout());

        paneltabelMakanan.setLayout(new java.awt.CardLayout());

        tableMakanan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID BARANG", "NAMA BARANG", "HARGA BARANG", "TANGGAL KADALUARSA", "ASAL PRODUK"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tableMakanan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMakananMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tableMakanan);

        paneltabelMakanan.add(jScrollPane2, "card2");

        jPanel2.add(paneltabelMakanan, "card2");

        paneltabelNon.setLayout(new java.awt.CardLayout());

        tableNon.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID BARANG", "NAMA BARANG", "HARGA BARANG", "BERAT BARANG", "UKURAN BARANG"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tableNon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableNonMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tableNon);

        paneltabelNon.add(jScrollPane3, "card2");

        jPanel2.add(paneltabelNon, "card3");

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 350, 550, 150));

        bg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/App Toko Sembako (1) (1).png"))); // NOI18N
        bg.setText("jLabel1");
        getContentPane().add(bg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 650, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void createbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createbtnActionPerformed
        if (txtId.getText().equals("") || txtNama.getText().equals("") || txtHarga.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Harap Isi Semua Data");
        }else{
            if (radioMakanan.isSelected()) {
                try {
                    String tanggal = JOptionPane.showInputDialog("MASUKKAN TANGGAL KADALUARSA");
                    String asal = JOptionPane.showInputDialog("MASUKKAN ASAL PRODUK");
                    if (tanggal == null  || asal == null) {
                        JOptionPane.showMessageDialog(null, "DATA HARUS TERISI SEMUA");
                    }else {
                        Barang.createBarang(txtId.getText(), txtNama.getText(), txtHarga.getText());
                        Makanan.createMakanan(txtId.getText(), txtNama.getText(), txtHarga.getText(), tanggal, asal);
                        readbtnActionPerformed(evt);
                        clearField();
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(MenuBarang.class.getName()).log(Level.SEVERE, null, ex);
                }
            }else if (radioNon.isSelected()){
                try {
                    String berat = JOptionPane.showInputDialog("MASUKKAN BERAT BARANG");
                    String ukuran = JOptionPane.showInputDialog("MASUKKAN UKURAN BARANG");
                    if (berat == null  || ukuran == null) {
                        JOptionPane.showMessageDialog(null, "DATA HARUS TERISI SEMUA");
                    }else {
                        Barang.createBarang(txtId.getText(), txtNama.getText(), txtHarga.getText());
                        NonMakanan.createNonMakanan(txtId.getText(), txtNama.getText(), txtHarga.getText(), berat, ukuran);
                        readbtnActionPerformed(evt);
                        clearField();
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(MenuBarang.class.getName()).log(Level.SEVERE, null, ex);
                }

            }else JOptionPane.showMessageDialog(null, "Harap Pilih Tipe Barang");            
        }
    }//GEN-LAST:event_createbtnActionPerformed

    private void deletebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletebtnActionPerformed
        if (txtId.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Harap Masukkan Id yang Ingin diHapus");
        }else{
            if (radioMakanan.isSelected()) {
                try {
                    Makanan.deleteMakanan(txtId.getText());
                    Barang.deleteBarang(txtId.getText());
                    readbtnActionPerformed(evt);
                    clearField();
                } catch (SQLException ex) {
                    Logger.getLogger(MenuBarang.class.getName()).log(Level.SEVERE, null, ex);
                }
            }else if (radioNon.isSelected()) {
                try {
                    NonMakanan.deleteNonMakanan(txtId.getText());
                    Barang.deleteBarang(txtId.getText());
                    readbtnActionPerformed(evt);
                    clearField();
                } catch (SQLException ex) {
                    Logger.getLogger(MenuBarang.class.getName()).log(Level.SEVERE, null, ex);
                }
            }else JOptionPane.showMessageDialog(null, "Harap Pilih Tipe Barang");  
        }
    }//GEN-LAST:event_deletebtnActionPerformed

    private void readbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_readbtnActionPerformed
        DefaultTableModel modelMakanan = (DefaultTableModel) tableMakanan.getModel();
        DefaultTableModel modelNon = (DefaultTableModel) tableNon.getModel();
        if (radioMakanan.isSelected()) {
            try {
                modelMakanan.setRowCount(0);
                changePanel(jPanel2, paneltabelMakanan);
                ArrayList<Makanan> dataMakanan = Makanan.readMakanan();
                for (Makanan makanan : dataMakanan) {
                    String[] data = {makanan.getIdBarang(),makanan.getNamaBarang(),makanan.getHargaBarang(),makanan.getTanggalKdl(),makanan.getAsalProduk()};
                    modelMakanan.addRow(data);
                }
            } catch (SQLException ex) {
                Logger.getLogger(MenuBarang.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else if (radioNon.isSelected()) {
            try {
                modelNon.setRowCount(0);
                changePanel(jPanel2, paneltabelNon);
                ArrayList<NonMakanan> dataNonMakanan = NonMakanan.readNonMakanan();
                for (NonMakanan nonmakanan : dataNonMakanan) {
                    String[] data = {nonmakanan.getIdBarang(),nonmakanan.getNamaBarang(),nonmakanan.getHargaBarang(),nonmakanan.getBeratBarang(),nonmakanan.getUkuranBarang()};
                    modelNon.addRow(data);
                }
            } catch (SQLException ex) {
                Logger.getLogger(MenuBarang.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else{
            JOptionPane.showMessageDialog(null, "Harap Pilih Tipe Barang");
        }
    }//GEN-LAST:event_readbtnActionPerformed

    private void updatebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatebtnActionPerformed
        if (txtId.getText().equals("") || txtNama.getText().equals("") || txtHarga.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Harap Isi Semua Data");
        }else if (radioMakanan.isSelected()) {
            String tanggal = JOptionPane.showInputDialog("MASUKKAN TANGGAL KADALUARSA BARU");
            String asal = JOptionPane.showInputDialog("MASUKKAN ASAL PRODUK BARU");
            if (tanggal == null  || asal == null) {
                JOptionPane.showMessageDialog(null, "DATA HARUS TERISI SEMUA");
            }else {
                try {
                    Makanan.updateMakanan(txtId.getText(),tanggal,asal );
                    Barang.updateBarang(txtId.getText(), txtNama.getText(), txtHarga.getText());
                    readbtnActionPerformed(evt);
                    clearField();
                } catch (SQLException ex) {
                    Logger.getLogger(MenuBarang.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }else if (radioNon.isSelected()) {
            String berat = JOptionPane.showInputDialog("MASUKKAN BERAT BARANG BARU");
            String ukuran = JOptionPane.showInputDialog("MASUKKAN UKURAN BARANG BARU");
            if (berat == null  || ukuran == null) {
                JOptionPane.showMessageDialog(null, "DATA HARUS TERISI SEMUA");
            }else {
                try {
                    NonMakanan.updateNonMakanan(txtId.getText(),berat,ukuran );
                    Barang.updateBarang(txtId.getText(), txtNama.getText(), txtHarga.getText());
                    readbtnActionPerformed(evt);
                    clearField();
                } catch (SQLException ex) {
                    Logger.getLogger(MenuBarang.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }else JOptionPane.showMessageDialog(null, "Harap Pilih Tipe Barang");
    }//GEN-LAST:event_updatebtnActionPerformed

   
    
    private void tableMakananMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMakananMouseClicked
        try {
            int selectedrow = tableMakanan.getSelectedRow();
            Object value = tableMakanan.getValueAt(selectedrow, 0);
            String qq = String.format("SELECT barang.*, makanan.tgl_kadaluarsa, makanan.asal_produk FROM barang INNER JOIN makanan ON barang.id_barang = makanan.id_barang WHERE barang.id_barang = '%s';", value);
            ResultSet rs = db.executeSelectQuery(qq);
            while (rs.next()) {                
                txtId.setText(rs.getString("id_barang"));
                txtHarga.setText(rs.getString("harga_barang"));
                txtNama.setText(rs.getString("nama_barang"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(MenuBarang.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_tableMakananMouseClicked

    private void tableNonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableNonMouseClicked
        try {
            int selectedrow = tableNon.getSelectedRow();
            Object value = tableNon.getValueAt(selectedrow, 0);
            String qq = String.format("SELECT barang.*, non_makanan.berat_barang, non_makanan.ukuran_barang FROM barang INNER JOIN non_makanan ON barang.id_barang = non_makanan.id_barang WHERE barang.id_barang = '%s';", value);
            ResultSet rs = db.executeSelectQuery(qq);
            while (rs.next()) {                
                txtId.setText(rs.getString("id_barang"));
                txtHarga.setText(rs.getString("harga_barang"));
                txtNama.setText(rs.getString("nama_barang"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(MenuBarang.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_tableNonMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        new KaryawanMenu().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuBarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuBarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuBarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuBarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new MenuBarang().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(MenuBarang.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel bg;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton createbtn;
    private javax.swing.JButton deletebtn;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JPanel paneltabelMakanan;
    private javax.swing.JPanel paneltabelNon;
    private javax.swing.JRadioButton radioMakanan;
    private javax.swing.JRadioButton radioNon;
    private javax.swing.JButton readbtn;
    private javax.swing.JTable tableMakanan;
    private javax.swing.JTable tableNon;
    private javax.swing.JTextField txtHarga;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtNama;
    private javax.swing.JButton updatebtn;
    // End of variables declaration//GEN-END:variables
}
